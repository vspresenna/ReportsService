package com.sainsburys.analytics.demo.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.Properties;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Repository;

import com.sainsburys.analytics.demo.dao.helper.SnowflakeConnection;
import com.sainsburys.analytics.demo.util.QueryGenerator;
import com.sainsburys.analytics.demo.vo.ReportSnippet;

@Repository
public class ReportViewerDao {
	
	@Autowired
	private QueryGenerator queryGen;
	
	@Autowired
	private SnowflakeConnection sfConn;
	
	public List<ReportSnippet> fetchReportList() {
		List<ReportSnippet> dashboardSnippet = new ArrayList<ReportSnippet>();
		dashboardSnippet.add(new ReportSnippet("RPT2323","Pd,time no trans","38409", "PRESENNA", "Customer profile","18-09-05 12:33"));
		dashboardSnippet.add(new ReportSnippet("RPT7363","Pd,time, trans-online-sainsburys","38380", "PRESENNA", "Customer profile","18-09-05 11:52"));
		dashboardSnippet.add(new ReportSnippet("RPT9323","Pd,time,cust,trans","38278", "PRESENNA", "Customer profile","18-09-0 16:29"));
		queryGen.generateQuery();
		Connection snowflakeConn = null;
		try {
			snowflakeConn = sfConn.getConnection(); // TODO DBCP
			System.out.println("Connection established");
			PreparedStatement ps = snowflakeConn.prepareStatement("select * from INC.CUSTOMER_DIM fetch first 1 row only");
			ResultSet rs = ps.executeQuery();
			System.out.println();
		} catch(SQLException e){
			e.printStackTrace();
		}
		System.out.println(snowflakeConn);
		return dashboardSnippet;
	}
	
	
}
