package com.sainsburys.analytics.demo.vo;

public class ReportDimension {
}
