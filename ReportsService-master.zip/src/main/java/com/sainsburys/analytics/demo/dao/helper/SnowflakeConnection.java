package com.sainsburys.analytics.demo.dao.helper;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.Properties;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

@Component
public class SnowflakeConnection {
	
	private static final Logger LOGGER = LogManager.getLogger(SnowflakeConnection.class);
	
	@Value("${snowflake.datasource.driver-class-name}")
	private String sf_driver;
	
	@Value("${snowflake.datasource.url}")
	private String sf_url;
	
	@Value("${snowflake.datasource.username}")
	private String sf_username;
	
	@Value("${snowflake.datasource.password}")
	private String sf_password;
	
	@Value("${snowflake.datasource.db}")
	private String sf_database;
	
	@Value("${snowflake.datasource.schema}")
	private String sf_schema;
	
	@Value("${snowflake.datasource.warehouse}")
	private String sf_warehouse;
	
	@Value("${snowflake.datasource.tracing}")
	private String sf_tracing;
	
	@Value("${snowflake.datasource.role}")
	private String sf_role;
	
	/**
	 * Gets Snowflake connection by populating connection 
	 * properties from application.properties file 
	 * @return Snowflake connection object
	 * @throws SQLException
	 */
	public Connection getConnection() throws SQLException {
		try {
			Class.forName("com.snowflake.client.jdbc.SnowFlakeDriver");
		} catch (ClassNotFoundException e) {
			LOGGER.error("Not able to classload SnowFlakeDriver");
		}
		Properties prop = getConnectionProperties();
		return DriverManager.getConnection(sf_url, prop);
	}

	/**
	 * Loads connection properties from application.properties file 
	 * @return connection properties
	 */
	private Properties getConnectionProperties() {
		LOGGER.debug("Loading Snowflake connection properties");
		Properties prop = new Properties();
		prop.put("user", sf_username);
		LOGGER.trace("Snowflake username: "+sf_username);
		prop.put("password", sf_password);
		LOGGER.trace("Snowflake password: "+sf_password); // TODO Base64 encode/decode
		prop.put("db", sf_database);
		LOGGER.trace("Snowflake database: "+sf_database);
		prop.put("schema", sf_schema);
		LOGGER.trace("Snowflake schema: "+sf_schema);
		prop.put("tracing", sf_tracing);
		LOGGER.trace("Snowflake tracing: "+sf_tracing);
		prop.put("warehouse", sf_warehouse);
		LOGGER.trace("Snowflake warehouse: "+sf_warehouse);
		prop.put("role", sf_role);
		return prop;
	}
}
