package com.sainsburys.analytics.demo.vo;

import java.io.Serializable;

public class ReportContent implements Serializable {

}
